<?php
/**
 * JJ's Junk 'n' Rubbish Removal Custom Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package JJs_Junk_Removal_Custom
 */

if ( ! defined( 'JJS_JUNK_REMOVAL_VERSION' ) ) {
	// Replace with the actual version of your theme.
	define( 'JJS_JUNK_REMOVAL_VERSION', '1.1.0' ); // Updated version
}

// Theme constants
define( 'JJS_JUNK_REMOVAL_INC_DIR', get_template_directory() . '/inc' );

/**
 * Theme setup.
 */
if ( ! function_exists( 'jjs_junk_removal_setup' ) ) :
	function jjs_junk_removal_setup() {
		load_theme_textdomain( 'jjs-junk-removal-custom', get_template_directory() . '/languages' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'custom-logo', array(
			'height'      => 100,
			'width'       => 300,
			'flex-width'  => true,
			'flex-height' => true,
		) );
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary Menu', 'jjs-junk-removal-custom' ),
            'footer'  => esc_html__( 'Footer Menu', 'jjs-junk-removal-custom' ),
		) );
		add_theme_support( 'html5', array(
			'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
		) );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support( 'elementor' );

        // Add editor styles - create editor-style.css if you want specific Gutenberg editor styling
        // add_editor_style( 'assets/css/editor-style.css' );
	}
endif;
add_action( 'after_setup_theme', 'jjs_junk_removal_setup' );

/**
 * Enqueue scripts and styles.
 */
function jjs_junk_removal_scripts() {
	wp_enqueue_style( 'jjs-google-fonts', 'https://fonts.googleapis.com/css2?family=Lato:wght@400&family=Montserrat:wght@700;800&family=Poppins:wght@400;500;700&display=swap', array(), null );
	wp_enqueue_style( 'jjs-junk-removal-style', get_stylesheet_uri(), array(), JJS_JUNK_REMOVAL_VERSION );
    wp_enqueue_style( 'jjs-custom-styles', get_template_directory_uri() . '/assets/css/style.css', array('jjs-junk-removal-style'), JJS_JUNK_REMOVAL_VERSION );
	wp_enqueue_script( 'jjs-junk-removal-main-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), JJS_JUNK_REMOVAL_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'jjs_junk_removal_scripts' );

/**
 * Register widget area.
 */
function jjs_junk_removal_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'jjs-junk-removal-custom' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'jjs-junk-removal-custom' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'jjs_junk_removal_widgets_init' );

/**
 * Load Theme Inc Customizations.
 */
require JJS_JUNK_REMOVAL_INC_DIR . '/customizer.php';
require JJS_JUNK_REMOVAL_INC_DIR . '/template-tags.php';
require JJS_JUNK_REMOVAL_INC_DIR . '/svg-icons.php';
require JJS_JUNK_REMOVAL_INC_DIR . '/extras.php';
// Optional: require JJS_JUNK_REMOVAL_INC_DIR . '/elementor.php'; if you add Elementor-specific functions

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function jjs_junk_removal_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'jjs_junk_removal_pingback_header' );
?>