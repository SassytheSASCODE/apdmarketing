<?php
/**
 * The template for displaying the footer
 * @package JJs_Junk_Removal_Custom
 */
?>
				</main><!-- #main -->
			</div><!-- #primary -->
		</div><!-- .container.main-content-container -->
	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="container footer-container">
			<div class="footer-widgets-area">
                <div class="footer-column footer-column-1 width-50">
                    <div class="footer-widget widget_text footer-copyright">
                        <div class="textwidget">
                            <p><?php echo wp_kses_post(get_theme_mod('jjs_copyright_text', '© ' . date('Y') . ' JJ’s Junk ’n’ Rubbish Removal. All rights reserved.')); ?></p>
                        </div>
                    </div>
                     <div class="footer-widget widget_text footer-contact-info">
                        <div class="textwidget">
                            <?php // You could make this a customizer option too ?>
                            <p>Contact us: info@jjsjunkremoval.com | Phone: (03) 1234 5678</p>
                        </div>
                    </div>
                </div>
                <div class="footer-column footer-column-2 width-50">
                    <?php
                    $social_networks = array( 'facebook', 'twitter', 'instagram', 'linkedin', 'youtube' );
                    $has_social_links = false;
                    foreach ($social_networks as $network) {
                        if (get_theme_mod('jjs_social_' . $network . '_url')) {
                            $has_social_links = true;
                            break;
                        }
                    }

                    if ($has_social_links) : ?>
                    <div class="footer-widget widget_social_icons">
                        <ul class="social-icons-list">
                            <?php foreach ( $social_networks as $network ) :
                                $social_url = get_theme_mod( 'jjs_social_' . $network . '_url' );
                                if ( ! empty( $social_url ) ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( $social_url ); ?>" target="_blank" rel="noopener noreferrer" class="social-icon-<?php echo esc_attr( $network ); ?>">
                                            <span class="screen-reader-text"><?php echo esc_html( ucfirst( $network ) ); ?></span>
                                            <?php echo jjs_junk_removal_get_svg( $network ); // SVG Icon ?>
                                        </a>
                                    </li>
                                <?php endif;
                            endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div><!-- .footer-widgets-area -->

            <?php if ( has_nav_menu( 'footer' ) ) : ?>
                <nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'jjs-junk-removal-custom' ); ?>">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'footer',
                            'menu_class'     => 'footer-menu',
                            'depth'          => 1,
                        )
                    );
                    ?>
                </nav><!-- .footer-navigation -->
            <?php endif; ?>
            
		</div><!-- .container -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>