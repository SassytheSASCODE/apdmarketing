<?php
/**
 * The header for our theme
 * @package JJs_Junk_Removal_Custom
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); // body_class() will now include 'has-sticky-header' if enabled ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'jjs-junk-removal-custom' ); ?></a>

	<header id="masthead" class="site-header <?php if (get_theme_mod('jjs_sticky_header_enabled', true)) echo 'sticky-header-enabled'; // Class to target for JS/CSS ?>" style="background-color: <?php echo esc_attr(get_theme_mod('header_bg_color', '#FFFFFF')); ?>;">
		<div class="container header-container">
			<div class="site-branding">
				<?php
				$custom_logo_id = get_theme_mod( 'custom_logo' );
				$logo_alt = "JJ's Junk 'n' Rubbish Removal Logo"; // Default, can be improved
				if ( $custom_logo_id ) {
					$logo_image_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
					$image_alt_text = get_post_meta( $custom_logo_id, '_wp_attachment_image_alt', true );
                    if ( ! empty( $image_alt_text ) ) {
                        $logo_alt = $image_alt_text;
                    }
					echo '<a href="' . esc_url( home_url( '/' ) ) . '" rel="home"><img src="' . esc_url($logo_image_url) . '" alt="' . esc_attr($logo_alt) . '" class="site-logo"></a>';
				} elseif ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
					the_custom_logo();
				} else {
					if ( is_front_page() && is_home() ) : ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php else : ?>
						<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
					<?php endif;
					$jjs_junk_removal_description = get_bloginfo( 'description', 'display' );
					if ( $jjs_junk_removal_description || is_customize_preview() ) : ?>
						<p class="site-description"><?php echo $jjs_junk_removal_description; ?></p>
					<?php endif; 
				} ?>
			</div><!-- .site-branding -->

			<nav id="site-navigation" class="main-navigation">
				<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                    <span class="menu-toggle-icon"></span> <?php // Icon for toggle, styled with CSS ?>
                    <span class="screen-reader-text"><?php esc_html_e( 'Menu', 'jjs-junk-removal-custom' ); ?></span>
                </button>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
                    'menu_class'     => 'nav-menu',
					'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				) ); ?>
			</nav><!-- #site-navigation -->

            <?php 
            $cta_text = "Get a Quote"; 
            $cta_url = "/contact";    
            if (!empty($cta_text) && !empty($cta_url)) : ?>
            <div class="header-cta-button">
                <a href="<?php echo esc_url(home_url($cta_url)); ?>" class="btn btn-primary">
                    <?php echo esc_html($cta_text); ?>
                </a>
            </div>
            <?php endif; ?>
		</div><!-- .container -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">
        <div class="container main-content-container">
            <div id="primary" class="content-area">
                <main id="main" class="site-main">