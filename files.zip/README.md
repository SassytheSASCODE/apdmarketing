# JJ’s Junk ’n’ Rubbish Removal Theme — Local Dev Setup

Welcome! This guide shows you how to get a full WordPress + your custom theme running in minutes—even if you’ve never coded before.

## 1. Prerequisites

• Install Docker & Docker Compose  
  • Docker Desktop on Mac/Windows or Docker Engine + Compose on Linux  
• A Code Editor (e.g. [VS Code](https://code.visualstudio.com/))

## 2. Folder Structure

Your project folder should look like this:

```
└── your-project-root/
    ├── docker-compose.yml
    ├── jjs-junk-removal-custom/       ← **your theme** lives here
    │   ├── style.css
    │   ├── functions.php
    │   ├── header.php
    │   ├── footer.php
    │   ├── assets/
    │   │   ├── css/style.css
    │   │   └── js/main.js
    │   └── template-parts/…
    ├── uploads/                       ← WordPress media uploads
    ├── start-dev.sh                   ← helper script to spin up Docker
    └── .gitignore
```

## 3. Bring Up WordPress

Open your terminal, `cd` into **your-project-root**, then run:

```bash
./start-dev.sh
```

This command will:

1. `docker-compose up -d`  
2. Download & start MySQL and WordPress containers  
3. Mount your theme folder so edits in VS Code immediately reflect in the site

## 4. Install WordPress

1. Visit [http://localhost:8000](http://localhost:8000)  
2. Follow the on-screen 5-minute install:
   - Site Title: anything you like  
   - Username/Password: pick your own  
   - Database details are pre-configured  

## 5. Activate Your Theme

1. Log in at [http://localhost:8000/wp-admin](http://localhost:8000/wp-admin)  
2. Go to **Appearance → Themes**  
3. Click **JJ’s Junk ’n Rubbish Removal (Elementor Custom)** → **Activate**

## 6. Edit & Live-Reload

1. Open `jjs-junk-removal-custom/` in your editor.  
2. Change CSS, PHP, or JS.  
3. Save & hit **Refresh** in the browser. Your theme updates instantly.

## 7. Build Pages with Elementor

1. In WP Admin → **Plugins** → **Add New** → search **Elementor** → **Install & Activate**.  
2. Pages → Add New → **Edit with Elementor**.  
3. Drag in headings, text, buttons. Your theme’s colors, fonts, and header/footer will wrap around them.

## 8. Customizer & Options

Go to **Appearance → Customize** to:

- Toggle the sticky header  
- Change the primary brand green  
- Update social links & copyright text  

All changes publish live without extra code.

---

You’re all set! Every time you save a file, refresh your browser. Enjoy exploring and learning by building your theme.  