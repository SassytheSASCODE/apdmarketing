=== JJ's Junk 'n' Rubbish Removal (Elementor Custom) ===
Contributors: SassytheSASCODE
Tags: one-column, two-columns, right-sidebar, custom-header, custom-menu, custom-logo, editor-style, featured-images, full-width-template, sticky-post, theme-options, translation-ready, blog, e-commerce, elementor
Requires at least: 5.8
Tested up to: (The latest WordPress version at the time of your release)
Requires PHP: 7.4
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A custom theme for JJ's Junk 'n' Rubbish Removal, designed to integrate seamlessly with the Elementor Free page builder. It features a custom header and footer based on provided designs, and global styles for a consistent brand experience.

== Description ==

This theme provides the foundational branding and structure for the JJ's Junk 'n' Rubbish Removal website. Key features include:

*   Customizable header with logo and navigation.
*   Branded footer with contact information and social media links.
*   Global styles (colors, typography, buttons) derived from your design system, applied to both theme elements and Elementor content.
*   Elementor-ready page templates for full-width and canvas layouts.
*   Responsive design for optimal viewing on all devices.
*   Sticky header functionality.

This theme is intended to be used with the Elementor page builder for creating and managing page content.

== Installation ==

1.  Download the theme ZIP file.
2.  In your WordPress admin panel, go to Appearance > Themes and click "Add New".
3.  Click "Upload Theme" and choose the ZIP file you downloaded.
4.  Click "Install Now" and then "Activate".
5.  Recommended: Install and activate the Elementor plugin.
6.  Setup:
    *   Go to Appearance > Customize > Site Identity to upload your logo.
    *   Go to Appearance > Menus. Create a "Primary Menu" (and optionally a "Footer Menu") and assign them to their respective theme locations. Populate the menu items.
    *   Start building your pages with Elementor!

== Frequently Asked Questions ==

= Does this theme require Elementor Pro? =
No, this theme is designed to work with Elementor Free. The theme provides the header, footer, and global styling. Elementor Free is used for building the content of your pages.

= How do I change the colors and fonts? =
The primary colors and fonts are defined in the theme's stylesheet (`assets/css/style.css`). For deeper customization, you may need to modify this file or use Elementor's global style settings (which can complement or override theme styles).

== Changelog ==

= 1.0.0 - 2025-06-15 =
* Initial release.

== Credits ==

*   Based on design specifications by SassytheSASCODE.
*   Uses Google Fonts: Lato, Montserrat, Poppins.

== Screenshot ==

A `screenshot.png` file (1200x900px recommended) should be placed in the theme's root directory. This image is displayed in Appearance > Themes. It should be a visually appealing representation of your theme's design, perhaps showing the homepage or a key service page.