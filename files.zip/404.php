<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php esc_html_e('Page Not Found', 'jjs-junk-removal-theme'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header>
        <?php get_template_part('template-parts/header'); ?>
    </header>

    <main>
        <section class="error-404 not-found">
            <header class="page-header">
                <h1 class="page-title"><?php esc_html_e('Oops! That page can’t be found.', 'jjs-junk-removal-theme'); ?></h1>
            </header>

            <div class="page-content">
                <p><?php esc_html_e('It looks like nothing was found at this location. Maybe try a search?', 'jjs-junk-removal-theme'); ?></p>
                <?php get_search_form(); ?>
            </div>
        </section>
    </main>

    <footer>
        <?php get_template_part('template-parts/footer'); ?>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>