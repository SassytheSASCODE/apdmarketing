#!/usr/bin/env bash
# Simple script to launch Docker containers

set -e

echo "Starting WordPress + MySQL via Docker Compose…"
docker-compose up -d
echo ""
echo "Containers are starting:"
docker-compose ps --services --filter "status=running"
echo ""
echo "Visit http://localhost:8000 to complete the WP install."