<?php
/**
 * Template Name: Elementor Canvas
 *
 * This template is for use with Elementor to create layouts that are
 * completely blank, without the theme's header, footer, or any other
 * theme elements. Elementor takes full control.
 *
 * @package JJs_Junk_Removal_Custom
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Elementor Pro might use its own hooks for this, but for Elementor Free,
// this ensures the basic setup for Elementor to function.
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php
	if ( ! current_theme_supports( 'title-tag' ) ) {
		echo '<title>' . wp_get_document_title() . '</title>';
	}
	wp_head();
	?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
/**
 * Before Elementor Canvas content.
 *
 * @since 1.0.0
 */
do_action( 'jjs_junk_removal_elementor_canvas_before_content' );

while ( have_posts() ) {
	the_post();
	the_content();
}

/**
 * After Elementor Canvas content.
 *
 * @since 1.0.0
 */
do_action( 'jjs_junk_removal_elementor_canvas_after_content' );

wp_footer();
?>
</body>
</html>