<?php
/**
 * SVG icons functions for the theme.
 * @package JJs_Junk_Removal_Custom
 */

function jjs_junk_removal_get_svg_icons() {
    $icons = array(
        'facebook'  => '<svg viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px"><path d="M12 2.04c-5.5 0-10 4.49-10 10s4.5 10 10 10 10-4.49 10-10S17.5 2.04 12 2.04zm1 6.5h-2v2h2v7h3v-7h2l.23-2H16v-1.45c0-.58.22-1.05.9-1.05H18V4h-2.56c-2.05 0-3.44 1.31-3.44 3.24V8.54z"/></svg>',
        'twitter'   => '<svg viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px"><path d="M22.46 6c-.77.35-1.6.58-2.46.67.9-.53 1.59-1.37 1.92-2.38-.84.5-1.78.86-2.79 1.07C18.25 4.49 17.08 4 15.79 4c-2.65 0-4.8 2.15-4.8 4.8 0 .38.04.75.13 1.11C7.85 9.71 4.98 8.28 3.12 6.04c-.4.69-.63 1.49-.63 2.34 0 1.66.84 3.13 2.12 3.99-.78-.03-1.51-.24-2.15-.59v.06c0 2.32 1.65 4.25 3.82 4.69-.4.11-.82.17-1.25.17-.31 0-.61-.03-.9-.08.61 1.9 2.38 3.28 4.48 3.32C5.61 18.83 3.8 19.42 2 19.42c-.39 0-.78-.02-1.16-.07C2.78 20.45 4.96 21 7.29 21c7.55 0 11.68-6.25 11.68-11.68l-.01-.53c.8-.58 1.49-1.3 2.02-2.1z"/></svg>',
        'instagram' => '<svg viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',
        'linkedin'  => '<svg viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.07c0-2.89-1.56-4.14-3.53-4.14-1.41 0-2.33.81-2.71 1.58h-.04v-1.37H9.25V18.5h2.94v-4.53c0-1.23.23-2.42 1.76-2.42 1.51 0 1.53 1.4 1.53 2.5v4.45h2.97zM6.71 8.97h2.94V18.5H6.71V8.97zm1.47-3.9a1.74 1.74 0 1 0 0-3.48 1.74 1.74 0 0 0 0 3.48z"/></svg>',
        'youtube'   => '<svg viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-.7.07-1.39.1-2.09.1L12 19c-2.19 0-3.8-.16-4.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.33-.28-2.65-.07-.7-.1-1.39-.1-2.09L5 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73 1.73.47-.13 1.33-.22 2.65-.28.7-.07 1.39-.1 2.09-.1L12 5c2.19 0 3.8.16 4.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',
        'logo_pattern_new' => '<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="jjBrandPattern" patternUnits="userSpaceOnUse" width="60" height="60" patternTransform="rotate(15)"><!-- Angled lines inspired by skip shape --> <path d="M0 10 L20 0 L25 5 L5 15 Z" fill="rgba(10, 140, 71, 0.03)"/><path d="M30 40 L50 30 L55 35 L35 45 Z" fill="rgba(10, 140, 71, 0.03)"/><!-- Small "wheel" dot --> <circle cx="50" cy="10" r="2.5" fill="rgba(28, 106, 66, 0.04)"/><circle cx="10" cy="50" r="2.5" fill="rgba(28, 106, 66, 0.04)"/></pattern></defs><rect width="60" height="60" fill="url(#jjBrandPattern)"/></svg>'
    );
    return $icons;
}

function jjs_junk_removal_get_svg( $icon_name ) {
    $icons = jjs_junk_removal_get_svg_icons();
    if ( isset( $icons[ $icon_name ] ) ) {
        return $icons[ $icon_name ];
    }
    return '';
}
?>