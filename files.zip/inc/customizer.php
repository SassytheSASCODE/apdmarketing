// ... (inside jjs_junk_removal_customize_register function) ...

    // --- Basic Colors Section (Example) ---
    // ...
    $wp_customize->add_setting( 'jjs_primary_color', array(
        'default'           => '#0A8C47', // UPDATED to new brand green
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );
    // ... (rest of the control) ...