<?php
/**
 * Custom extra functions for this theme
 *
 * @package JJs_Junk_Removal_Custom
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function jjs_junk_removal_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

    // Adds a class if sticky header is enabled
    if ( get_theme_mod('jjs_sticky_header_enabled', true) ) {
        $classes[] = 'has-sticky-header';
    }

	return $classes;
}
add_filter( 'body_class', 'jjs_junk_removal_body_classes' );

/**
 * Add a custom excerpt read more link
 */
function jjs_junk_removal_excerpt_more( $more ) {
    if ( ! is_admin() ) {
        global $post;
        return ' &hellip; <a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="read-more">' . __( 'Read More', 'jjs-junk-removal-custom' ) . '</a>';
    }
    return $more;
}
add_filter( 'excerpt_more', 'jjs_junk_removal_excerpt_more' );

/**
 * Filter the except length to 30 words.
 *
 * @param int $length Excerpt length.
 * @return int (Maybe) modified excerpt length.
 */
function jjs_junk_removal_custom_excerpt_length( $length ) {
    return 30;
}
add_filter( 'excerpt_length', 'jjs_junk_removal_custom_excerpt_length', 999 );

// Add other theme-specific hooks or functions here.
// For example, modifying query vars, adding image sizes, etc.

/**
 * Add preconnect for Google Fonts for performance.
 */
function jjs_junk_removal_resource_hints( $urls, $relation_type ) {
    if ( wp_style_is( 'jjs-google-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
        $urls[] = array(
            'href' => 'https://fonts.gstatic.com',
            'crossorigin',
        );
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'jjs_junk_removal_resource_hints', 10, 2 );

?>