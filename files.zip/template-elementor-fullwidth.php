<?php
/**
 * Template Name: Elementor Full Width
 *
 * This template is for use with Elementor to create full-width layouts
 * that still use the theme's header and footer. It removes the default
 * page title display and any sidebars.
 *
 * @package JJs_Junk_Removal_Custom
 */

get_header();
?>

<div id="primary" class="content-area content-area-fullwidth">
	<main id="main" class="site-main site-main-fullwidth" role="main">
		<?php
		while ( have_posts() ) :
			the_post();

			// Elementor will render its content here
			the_content();

			// If comments are open or we have at least one comment, load up the comment template.
			// You might want to disable comments on Elementor pages by default.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>
	</main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();