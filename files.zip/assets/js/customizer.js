/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {

	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

    // Copyright Text
	wp.customize( 'jjs_copyright_text', function( value ) {
		value.bind( function( to ) {
            var $copyrightElement = $( '.site-footer .footer-copyright p' );
            if ( to ) {
                $copyrightElement.html( to ); // Use .html() if copyright text might contain simple HTML
            } else {
                $copyrightElement.empty();
            }
		} );
	} );

    // Primary Color (Example)
    wp.customize( 'jjs_primary_color', function( value ) {
        value.bind( function( newval ) {
            document.documentElement.style.setProperty('--primary-color-custom', newval );
            // You might need to update specific elements if they don't use the CSS variable directly
            // For example: $('.btn-primary').css('background-color', newval);
        } );
    } );

    // Sticky Header Toggle (just an example, actual sticky is CSS/JS based on body class)
    wp.customize( 'jjs_sticky_header_enabled', function( value ) {
        value.bind( function( to ) {
            if (to) {
                $('body').addClass('has-sticky-header');
                $('#masthead').addClass('sticky-header-enabled');
            } else {
                $('body').removeClass('has-sticky-header');
                 $('#masthead').removeClass('sticky-header-enabled is-sticky'); // Remove is-sticky too
            }
            // Re-evaluate sticky logic if needed, or rely on page reload for full effect
        });
    });

} )( jQuery );