/**
 * Main JavaScript file for JJ's Junk 'n' Rubbish Removal Custom Theme
 */
(function($) {
    'use strict';

    // Debounce function
    function debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // Animate on Scroll
    var animateOnScroll = debounce(function() {
        var $window = $(window);
        var windowHeight = $window.height();
        var windowScrollTop = $window.scrollTop();

        $('.animate-on-scroll').each(function() {
            var $element = $(this);
            var elementTop = $element.offset().top;
            var elementHeight = $element.outerHeight();

            // Check if element is in viewport (with a bit of offset)
            if (elementTop < (windowScrollTop + windowHeight - 50) && (elementTop + elementHeight) > windowScrollTop + 50) {
                $element.addClass('is-visible');
            } else {
                // Optional: remove class if you want animations to re-trigger on scroll up
                // $element.removeClass('is-visible');
            }
        });
    }, 100); // Adjust debounce time as needed (e.g., 50-150ms)


    // Document Ready
    $(document).ready(function() {

        // Initial check for animations
        animateOnScroll();
        $(window).on('scroll resize', animateOnScroll);


        // Sticky Header
        var $header = $('#masthead'); // Target the main header element
        // Check if sticky header is enabled via body class from Customizer
        if ($('body').hasClass('has-sticky-header') && $header.hasClass('sticky-header-enabled')) {
            var stickyNavTop = $header.offset().top;
            var headerHeight = $header.outerHeight();
            var $adminBar = $('#wpadminbar');
            var adminBarHeight = $adminBar.length ? $adminBar.outerHeight() : 0;

            var stickyNav = function() {
                var scrollTop = $(window).scrollTop();

                if (scrollTop > stickyNavTop) {
                    $header.addClass('is-sticky');
                    // Add placeholder only if it doesn't exist yet
                    if (!$('.header-placeholder').length) {
                         $header.after('<div class="header-placeholder" style="height:' + headerHeight + 'px;"></div>');
                    }
                   $header.css('top', adminBarHeight + 'px'); // Adjust for admin bar
                } else {
                    $header.removeClass('is-sticky');
                    $('.header-placeholder').remove();
                    $header.css('top', '');
                }
            };

            stickyNav(); // Call on load
            $(window).scroll(stickyNav);
        }


        // Smooth scrolling for internal links
        $('a[href*="#"]').not('[href="#"]').not('[href="#0"]').not('[data-toggle]').not('[data-slide]').on('click', function(event) {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    event.preventDefault();
                    var targetOffset = target.offset().top;
                    // Adjust for sticky header height if it's active
                    if ($header.hasClass('is-sticky')) {
                        targetOffset -= $header.outerHeight();
                    }
                     targetOffset -= adminBarHeight; // Adjust for admin bar if present

                    $('html, body').animate({
                        scrollTop: targetOffset
                    }, 800, function() {
                        // Optional callback after animation
                        var $target = $(target);
                        $target.trigger('focus');
                        if ($target.is(":focus")) { // Checking if the target was focused
                            return false;
                        } else {
                            $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
                            $target.trigger('focus'); // Set focus again
                        }
                    });
                }
            }
        });


        // Mobile Menu Toggle
        var $menuToggle = $('.menu-toggle');
        var $navMenu = $('#site-navigation .nav-menu');

        if ($menuToggle.length && $navMenu.length) {
            $menuToggle.on('click', function() {
                $(this).toggleClass('toggled-on');
                $navMenu.toggleClass('toggled-on').slideToggle(250); // Added slideToggle
                var isExpanded = $(this).attr('aria-expanded') === 'true' || false;
                $(this).attr('aria-expanded', !isExpanded);
            });
        }

        // FAQ Toggle (if using theme-styled FAQs)
        $('.faq-question').on('click', function() {
            var $thisQuestion = $(this);
            var $thisAnswer = $thisQuestion.next('.faq-answer');
            var $parentItem = $thisQuestion.parent('.faq-item');

            $parentItem.toggleClass('active');
            $thisAnswer.slideToggle(250);

            if ($parentItem.hasClass('active')) {
                $thisQuestion.attr('aria-expanded', 'true');
                $thisAnswer.attr('aria-hidden', 'false');
            } else {
                $thisQuestion.attr('aria-expanded', 'false');
                $thisAnswer.attr('aria-hidden', 'true');
            }
        });
         // Initialize ARIA for FAQs
        $('.faq-item').each(function(){
            var $item = $(this);
            var $question = $item.find('.faq-question');
            var $answer = $item.find('.faq-answer');
            if($item.hasClass('active')){
                $question.attr('aria-expanded', 'true');
                $answer.attr('aria-hidden', 'false');
            } else {
                $question.attr('aria-expanded', 'false');
                $answer.attr('aria-hidden', 'true');
                $answer.hide(); // Ensure initially hidden if not active
            }
        });


    }); // End Document Ready

})(jQuery);