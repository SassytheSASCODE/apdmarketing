<?php
get_header(); ?>

<main id="main" class="site-main" role="main">

    <section class="search-results">
        <header class="page-header">
            <h1 class="page-title"><?php printf( esc_html__( 'Search Results for: %s', 'jjs-junk-removal-theme' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
        </header>

        <?php if ( have_posts() ) : ?>
            <div class="search-results-list">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <header class="entry-header">
                            <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        </header>

                        <div class="entry-summary">
                            <?php the_excerpt(); ?>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php the_posts_navigation(); ?>
        <?php else : ?>
            <article class="no-results not-found">
                <header class="entry-header">
                    <h2 class="entry-title"><?php esc_html_e( 'Nothing Found', 'jjs-junk-removal-theme' ); ?></h2>
                </header>

                <div class="entry-content">
                    <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with different keywords.', 'jjs-junk-removal-theme' ); ?></p>
                    <?php get_search_form(); ?>
                </div>
            </article>
        <?php endif; ?>
    </section>

</main>

<?php
get_sidebar();
get_footer();
?>