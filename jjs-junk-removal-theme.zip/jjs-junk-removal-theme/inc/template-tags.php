<?php
function jjs_junk_removal_posted_on() {
    $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
    $time_string = sprintf($time_string,
        esc_attr(get_the_date('c')),
        esc_html(get_the_date())
    );

    $byline = sprintf(
        esc_html_x('by %s', 'post author', 'jjs-junk-removal'),
        '<span class="author vcard">' . esc_html(get_the_author()) . '</span>'
    );

    echo '<span class="posted-on">' . $time_string . '</span><span class="byline"> ' . $byline . '</span>';
}

function jjs_junk_removal_entry_footer() {
    if ('post' === get_post_type()) {
        $categories_list = get_the_category_list(', ');
        if ($categories_list) {
            printf('<span class="cat-links">' . esc_html__('Posted in %1$s', 'jjs-junk-removal') . '</span>', $categories_list);
        }

        $tags_list = get_the_tag_list('', ', ');
        if ($tags_list) {
            printf('<span class="tags-links">' . esc_html__('Tagged %1$s', 'jjs-junk-removal') . '</span>', $tags_list);
        }
    }
}

function jjs_junk_removal_post_thumbnail() {
    if (post_password_required() || is_attachment()) {
        return;
    }
    if (has_post_thumbnail()) {
        echo '<div class="post-thumbnail">';
        the_post_thumbnail();
        echo '</div>';
    }
}

function jjs_junk_removal_excerpt($length = 55) {
    return wp_trim_words(get_the_excerpt(), $length);
}
?>