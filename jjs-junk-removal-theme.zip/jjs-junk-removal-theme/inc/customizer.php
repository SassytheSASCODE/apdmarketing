<?php
function jjs_junk_removal_customize_register( $wp_customize ) {
    // Site Identity
    $wp_customize->add_section( 'jjs_junk_removal_site_identity', array(
        'title'    => __( 'Site Identity', 'jjs-junk-removal' ),
        'priority' => 30,
    ) );

    $wp_customize->add_setting( 'jjs_junk_removal_logo' );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'jjs_junk_removal_logo', array(
        'label'    => __( 'Logo', 'jjs-junk-removal' ),
        'section'  => 'jjs_junk_removal_site_identity',
        'settings' => 'jjs_junk_removal_logo',
    ) ) );

    // Colors
    $wp_customize->add_section( 'jjs_junk_removal_colors', array(
        'title'    => __( 'Colors', 'jjs-junk-removal' ),
        'priority' => 35,
    ) );

    $wp_customize->add_setting( 'jjs_junk_removal_primary_color', array(
        'default'   => '#ED4E09',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'jjs_junk_removal_primary_color', array(
        'label'    => __( 'Primary Color', 'jjs-junk-removal' ),
        'section'  => 'jjs_junk_removal_colors',
        'settings' => 'jjs_junk_removal_primary_color',
    ) ) );

    // Typography
    $wp_customize->add_section( 'jjs_junk_removal_typography', array(
        'title'    => __( 'Typography', 'jjs-junk-removal' ),
        'priority' => 40,
    ) );

    $wp_customize->add_setting( 'jjs_junk_removal_body_font', array(
        'default'   => 'Noto Sans',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'jjs_junk_removal_body_font', array(
        'label'    => __( 'Body Font', 'jjs-junk-removal' ),
        'section'  => 'jjs_junk_removal_typography',
        'type'     => 'select',
        'choices'  => array(
            'Noto Sans' => 'Noto Sans',
            'Montserrat' => 'Montserrat',
            'Poppins'    => 'Poppins',
        ),
    ) );

    // Additional settings can be added here
}

add_action( 'customize_register', 'jjs_junk_removal_customize_register' );

function jjs_junk_removal_customize_css() {
    ?>
    <style type="text/css">
        body {
            font-family: <?php echo get_theme_mod( 'jjs_junk_removal_body_font', 'Noto Sans' ); ?>;
        }
        a {
            color: <?php echo get_theme_mod( 'jjs_junk_removal_primary_color', '#ED4E09' ); ?>;
        }
    </style>
    <?php
}

add_action( 'wp_head', 'jjs_junk_removal_customize_css' );
?>