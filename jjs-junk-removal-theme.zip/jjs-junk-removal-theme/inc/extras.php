<?php
// extras.php

if ( ! function_exists( 'jjs_junk_removal_setup' ) ) :
    function jjs_junk_removal_setup() {
        // Add theme support for various features
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'custom-logo', array(
            'height'      => 100,
            'width'       => 400,
            'flex-height' => true,
            'flex-width'  => true,
        ) );
        add_theme_support( 'title-tag' );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    }
endif;
add_action( 'after_setup_theme', 'jjs_junk_removal_setup' );

if ( ! function_exists( 'jjs_junk_removal_excerpt_length' ) ) :
    function jjs_junk_removal_excerpt_length( $length ) {
        return 20; // Set the excerpt length to 20 words
    }
endif;
add_filter( 'excerpt_length', 'jjs_junk_removal_excerpt_length' );

if ( ! function_exists( 'jjs_junk_removal_custom_excerpt_more' ) ) :
    function jjs_junk_removal_custom_excerpt_more( $more ) {
        return '...'; // Customize the excerpt more string
    }
endif;
add_filter( 'excerpt_more', 'jjs_junk_removal_custom_excerpt_more' );

if ( ! function_exists( 'jjs_junk_removal_get_social_links' ) ) :
    function jjs_junk_removal_get_social_links() {
        return array(
            'facebook'  => 'https://facebook.com/jjsjunkremoval',
            'twitter'   => 'https://twitter.com/jjsjunkremoval',
            'instagram' => 'https://instagram.com/jjsjunkremoval',
            'linkedin'  => 'https://linkedin.com/company/jjsjunkremoval',
        );
    }
endif;

if ( ! function_exists( 'jjs_junk_removal_enqueue_scripts' ) ) :
    function jjs_junk_removal_enqueue_scripts() {
        wp_enqueue_style( 'jjs-junk-removal-style', get_stylesheet_uri() );
        wp_enqueue_script( 'jjs-junk-removal-main', get_template_directory_uri() . '/assets/js/main.js', array(), null, true );
    }
endif;
add_action( 'wp_enqueue_scripts', 'jjs_junk_removal_enqueue_scripts' );
?>