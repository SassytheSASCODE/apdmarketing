<?php
function jjs_junk_removal_seo_meta_tags() {
    if (is_single() || is_page()) {
        global $post;
        $meta_description = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
        $meta_keywords = get_post_meta($post->ID, '_yoast_wpseo_focuskw', true);
        $meta_title = get_the_title($post->ID);

        echo '<meta name="description" content="' . esc_attr($meta_description) . '">' . "\n";
        echo '<meta name="keywords" content="' . esc_attr($meta_keywords) . '">' . "\n";
        echo '<title>' . esc_html($meta_title) . '</title>' . "\n";
    }
}
add_action('wp_head', 'jjs_junk_removal_seo_meta_tags');

function jjs_junk_removal_schema_markup() {
    if (is_single() || is_page()) {
        global $post;
        $schema_data = [
            '@context' => 'https://schema.org',
            '@type' => 'LocalBusiness',
            'name' => 'JJ\'s Junk \'n\' Rubbish Removal',
            'url' => get_permalink($post->ID),
            'logo' => get_theme_file_uri('/assets/images/logo.png'),
            'description' => get_the_excerpt($post->ID),
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => '123 Junk St',
                'addressLocality' => 'Your City',
                'addressRegion' => 'Your State',
                'postalCode' => '12345',
                'addressCountry' => 'US'
            ],
            'telephone' => '+1-234-567-8901',
            'openingHours' => 'Mo,Tu,We,Th,Fr 08:00-17:00',
            'sameAs' => [
                'https://www.facebook.com/jjsjunkremoval',
                'https://twitter.com/jjsjunkremoval',
                'https://www.instagram.com/jjsjunkremoval'
            ]
        ];

        echo '<script type="application/ld+json">' . json_encode($schema_data) . '</script>' . "\n";
    }
}
add_action('wp_head', 'jjs_junk_removal_schema_markup');
?>