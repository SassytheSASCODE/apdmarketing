<div class="sidebar">
    <h2>About JJ's Junk 'n' Rubbish Removal</h2>
    <p>Your trusted partner for efficient and eco-friendly junk removal services. We help you declutter your space with ease!</p>
    
    <h3>Quick Links</h3>
    <ul>
        <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
        <li><a href="<?php echo esc_url(home_url('/services')); ?>">Our Services</a></li>
        <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact Us</a></li>
        <li><a href="<?php echo esc_url(home_url('/faq')); ?>">FAQs</a></li>
        <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Blog</a></li>
    </ul>

    <h3>Follow Us</h3>
    <ul class="social-media">
        <li><a href="https://facebook.com/jjsjunkremoval" target="_blank">Facebook</a></li>
        <li><a href="https://twitter.com/jjsjunkremoval" target="_blank">Twitter</a></li>
        <li><a href="https://instagram.com/jjsjunkremoval" target="_blank">Instagram</a></li>
    </ul>
</div>