<?php
// footer.php for JJ's Junk 'n' Rubbish Removal theme

?>

<footer class="site-footer">
    <div class="footer-content">
        <div class="footer-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="JJ's Junk 'n' Rubbish Removal Logo">
            </a>
        </div>
        <div class="footer-links">
            <ul>
                <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
                <li><a href="<?php echo esc_url(home_url('/services')); ?>">Our Services</a></li>
                <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
                <li><a href="<?php echo esc_url(home_url('/faq')); ?>">FAQ</a></li>
                <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Blog</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> JJ's Junk 'n' Rubbish Removal. All rights reserved.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>