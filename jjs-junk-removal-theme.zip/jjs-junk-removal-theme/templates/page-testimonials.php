<?php
/**
 * Template Name: Testimonials
 */

get_header(); ?>

<div class="testimonials-section">
    <h1><?php the_title(); ?></h1>
    <div class="testimonials-container">
        <?php
        // Query to get testimonials
        $args = array(
            'post_type' => 'testimonial',
            'posts_per_page' => -1,
        );
        $testimonials = new WP_Query($args);

        if ($testimonials->have_posts()) :
            while ($testimonials->have_posts()) : $testimonials->the_post(); ?>
                <div class="testimonial-item">
                    <h2><?php the_title(); ?></h2>
                    <div class="testimonial-content">
                        <?php the_content(); ?>
                    </div>
                    <p class="testimonial-author"><?php echo get_post_meta(get_the_ID(), 'author_name', true); ?></p>
                </div>
            <?php endwhile;
            wp_reset_postdata();
        else : ?>
            <p><?php esc_html_e('No testimonials found.', 'jjs-junk-removal-theme'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>