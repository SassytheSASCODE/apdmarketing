<?php
/**
 * Template Name: Home
 */

get_header(); ?>

<div class="hero-section">
    <h1>Welcome to JJ's Junk 'n' Rubbish Removal</h1>
    <p>Your trusted partner for hassle-free junk removal services.</p>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="cta-button">Get a Free Quote</a>
</div>

<section class="services-preview">
    <h2>Our Services</h2>
    <div class="services-grid">
        <div class="service-item">
            <h3>Residential Junk Removal</h3>
            <p>Efficient and eco-friendly removal of unwanted items from your home.</p>
        </div>
        <div class="service-item">
            <h3>Commercial Junk Removal</h3>
            <p>Tailored solutions for businesses to clear out unwanted clutter.</p>
        </div>
        <div class="service-item">
            <h3>Construction Debris Removal</h3>
            <p>Safe and quick removal of debris from construction sites.</p>
        </div>
    </div>
</section>

<section class="testimonials">
    <h2>What Our Customers Say</h2>
    <div class="testimonial-item">
        <p>"JJ's Junk 'n' Rubbish Removal was fast and professional. Highly recommend!"</p>
        <cite>- Sarah L.</cite>
    </div>
    <div class="testimonial-item">
        <p>"Great service! They made the process so easy for us."</p>
        <cite>- Mike T.</cite>
    </div>
</section>

<section class="contact-cta">
    <h2>Ready to Clear the Clutter?</h2>
    <p>Contact us today for a free estimate!</p>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="cta-button">Contact Us</a>
</section>

<?php get_footer(); ?>