<?php
/**
 * Template Name: Contact
 */

get_header(); ?>

<div class="contact-page">
    <h1><?php the_title(); ?></h1>
    <div class="contact-info">
        <p>If you have any questions or need assistance, feel free to reach out to us!</p>
        <h2>Contact Information</h2>
        <p>Email: <a href="mailto:info@jjsjunkremoval.com">info@jjsjunkremoval.com</a></p>
        <p>Phone: <a href="tel:+1234567890">+1 (234) 567-890</a></p>
        <p>Address: 123 Junk St, Rubbish City, RC 12345</p>
    </div>
    
    <div class="contact-form">
        <h2>Get in Touch</h2>
        <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="POST">
            <input type="hidden" name="action" value="contact_form_submission">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            
            <button type="submit">Send Message</button>
        </form>
    </div>
    
    <div class="map">
        <h2>Our Location</h2>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509198!2d144.9537353153163!3d-37.81627997975157!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f0f0f0f%3A0x0!2s123%20Junk%20St%2C%20Rubbish%20City%2C%20RC%2012345!5e0!3m2!1sen!2sus!4v1616161616161!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
</div>

<?php get_footer(); ?>