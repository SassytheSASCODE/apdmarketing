<?php
/**
 * Template Name: About
 */

get_header(); ?>

<div class="about-page">
    <section class="about-intro">
        <h1>About JJ's Junk 'n' Rubbish Removal</h1>
        <p>At JJ's Junk 'n' Rubbish Removal, we are dedicated to providing top-notch rubbish removal services to help you declutter your space. Our mission is to make your life easier by offering reliable, efficient, and eco-friendly junk removal solutions.</p>
    </section>

    <section class="about-mission">
        <h2>Our Mission</h2>
        <p>Our mission is to provide exceptional rubbish removal services while promoting sustainability and responsible waste management. We strive to minimize landfill waste by recycling and donating items whenever possible.</p>
    </section>

    <section class="about-values">
        <h2>Our Values</h2>
        <ul>
            <li>Customer Satisfaction: We prioritize our customers and aim to exceed their expectations.</li>
            <li>Integrity: We operate with honesty and transparency in all our dealings.</li>
            <li>Environmental Responsibility: We are committed to reducing our environmental impact.</li>
            <li>Community Engagement: We actively participate in community initiatives and support local charities.</li>
        </ul>
    </section>

    <section class="about-team">
        <h2>Meet Our Team</h2>
        <p>Our team of experienced professionals is passionate about helping you reclaim your space. With a friendly attitude and a commitment to service, we ensure that every job is completed to the highest standards.</p>
    </section>
</div>

<?php get_footer(); ?>