<?php
/**
 * Template Name: FAQ
 */

get_header(); ?>

<main id="main" class="site-main" role="main">
    <section class="faq-section">
        <div class="container">
            <h1 class="faq-title">Frequently Asked Questions</h1>
            <div class="faq-list">
                <div class="faq-item">
                    <h2 class="faq-question">What services do you offer?</h2>
                    <div class="faq-answer">
                        <p>We offer a variety of rubbish removal services including residential, commercial, and construction waste removal.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h2 class="faq-question">How do I schedule a pickup?</h2>
                    <div class="faq-answer">
                        <p>You can schedule a pickup by contacting us through our contact page or by calling our customer service.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h2 class="faq-question">What are your pricing options?</h2>
                    <div class="faq-answer">
                        <p>Our pricing varies based on the volume and type of rubbish. Please contact us for a free quote.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h2 class="faq-question">Do you recycle?</h2>
                    <div class="faq-answer">
                        <p>Yes, we are committed to recycling as much waste as possible to minimize environmental impact.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h2 class="faq-question">What areas do you serve?</h2>
                    <div class="faq-answer">
                        <p>We serve a wide range of areas. Please check our service area page for more details.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
?>