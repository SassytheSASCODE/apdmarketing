<?php
/**
 * Template Name: Services
 */

get_header(); ?>

<div class="services-page">
    <h1><?php the_title(); ?></h1>
    <div class="services-intro">
        <p>At JJ's Junk 'n' Rubbish Removal, we offer a variety of services to help you clear out unwanted items and keep your space clutter-free. Our team is dedicated to providing efficient and eco-friendly rubbish removal solutions.</p>
    </div>

    <div class="services-list">
        <h2>Our Services</h2>
        <ul>
            <li>
                <h3>Residential Junk Removal</h3>
                <p>We help homeowners declutter their spaces by removing unwanted furniture, appliances, and other household items.</p>
            </li>
            <li>
                <h3>Commercial Junk Removal</h3>
                <p>Our team assists businesses in clearing out old office furniture, equipment, and other commercial waste.</p>
            </li>
            <li>
                <h3>Construction Debris Removal</h3>
                <p>We provide efficient removal of construction debris, ensuring your site is clean and safe.</p>
            </li>
            <li>
                <h3>Eco-Friendly Disposal</h3>
                <p>We prioritize environmentally responsible disposal methods, recycling and donating items whenever possible.</p>
            </li>
        </ul>
    </div>

    <div class="cta-section">
        <h2>Ready to Clear Out the Clutter?</h2>
        <p>Contact us today for a free estimate!</p>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="cta-button">Get a Quote</a>
    </div>
</div>

<?php
get_footer();
?>