// filepath: jjs-junk-removal-theme/jjs-junk-removal-theme/assets/js/main.js
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for internal links
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Toggle FAQ answers
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', function() {
            const answer = item.querySelector('.faq-answer');
            answer.classList.toggle('active');
            const isActive = answer.classList.contains('active');
            answer.style.maxHeight = isActive ? answer.scrollHeight + 'px' : '0';
        });
    });

    // Sticky navigation
    const navbar = document.querySelector('.navbar');
    const sticky = navbar.offsetTop;
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > sticky) {
            navbar.classList.add('sticky');
        } else {
            navbar.classList.remove('sticky');
        }
    });
});