<?php
// Filepath: jjs-junk-removal-theme/functions.php

if ( ! function_exists( 'jjs_junk_removal_setup' ) ) :
    function jjs_junk_removal_setup() {
        // Add support for various WordPress features
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'custom-logo' );
        add_theme_support( 'custom-background' );
        
        // Register navigation menus
        register_nav_menus( array(
            'primary' => __( 'Primary Menu', 'jjs-junk-removal' ),
            'footer'  => __( 'Footer Menu', 'jjs-junk-removal' ),
        ) );
    }
endif;
add_action( 'after_setup_theme', 'jjs_junk_removal_setup' );

function jjs_junk_removal_scripts() {
    // Enqueue styles and scripts
    wp_enqueue_style( 'jjs-junk-removal-style', get_stylesheet_uri() );
    wp_enqueue_script( 'jjs-junk-removal-main', get_template_directory_uri() . '/assets/js/main.js', array(), null, true );
}
add_action( 'wp_enqueue_scripts', 'jjs_junk_removal_scripts' );

// Include additional files
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/seo.php';

// Register widget area
function jjs_junk_removal_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Sidebar', 'jjs-junk-removal' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Add widgets here.', 'jjs-junk-removal' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'jjs_junk_removal_widgets_init' );

// Custom excerpt length
function jjs_junk_removal_custom_excerpt_length( $length ) {
    return 20; // Change this number to set the desired excerpt length
}
add_filter( 'excerpt_length', 'jjs_junk_removal_custom_excerpt_length' );

// Add SEO support
function jjs_junk_removal_seo_meta() {
    if ( is_single() ) {
        // Add custom meta tags for SEO
        echo '<meta name="description" content="' . get_the_excerpt() . '">';
    }
}
add_action( 'wp_head', 'jjs_junk_removal_seo_meta' );
?>